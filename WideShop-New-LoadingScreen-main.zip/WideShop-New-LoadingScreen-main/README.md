# WideShop-New-LoadingScreen
Bu Script WideShop'a aittir herhangi bir satış vesaire yasaktır.
